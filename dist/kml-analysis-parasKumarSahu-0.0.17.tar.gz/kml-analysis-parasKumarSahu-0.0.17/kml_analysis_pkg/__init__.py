def call_my_name(name):
	print("Hi", name, "!!!!")